import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from scipy.signal import welch

# ─────────────────────────────────────────
# PFAD - nur hier anpassen!
# ─────────────────────────────────────────
PFAD = "C:/Users/karst/OneDrive/Desktop/program"

# ─────────────────────────────────────────
# 1. DATEN LADEN & VORBEREITEN
# ─────────────────────────────────────────
def load_session(filepath):
    df = pd.read_csv(filepath)

    # Lineare Beschleunigung (ohne Schwerkraft)
    df['lin_x'] = df['accelerationX'] - df['gravityX']
    df['lin_y'] = df['accelerationY'] - df['gravityY']
    df['lin_z'] = df['accelerationZ'] - df['gravityZ']

    # Bewegungs-Magnitude
    df['magnitude'] = np.sqrt(df['lin_x']**2 + df['lin_y']**2 + df['lin_z']**2)

    return df


# ─────────────────────────────────────────
# 2. FEATURE EXTRACTION
# ─────────────────────────────────────────
def extract_features(df, session_name, label):
    f = {'session': session_name, 'label': label}

    # ── Zeitbereich: Lineare Beschleunigung ──
    for axis in ['x', 'y', 'z']:
        col = df[f'lin_{axis}']
        f[f'lin_{axis}_mean'] = col.mean()
        f[f'lin_{axis}_std']  = col.std()
        f[f'lin_{axis}_max']  = col.abs().max()

    # ── Magnitude ────────────────────────────
    f['magnitude_mean']  = df['magnitude'].mean()
    f['magnitude_std']   = df['magnitude'].std()
    f['magnitude_max']   = df['magnitude'].max()
    f['stillness_ratio'] = (df['magnitude'] < 0.02).mean()
    f['movement_events'] = (df['magnitude'] > df['magnitude'].quantile(0.75)).sum()

    # ── Gyroscope (Rotation) ─────────────────
    for axis in ['X', 'Y', 'Z']:
        col = df[f'rotationRate{axis}']
        f[f'rot_{axis.lower()}_mean'] = col.mean()
        f[f'rot_{axis.lower()}_std']  = col.std()
        f[f'rot_{axis.lower()}_max']  = col.abs().max()

    # ── Euler-Winkel ─────────────────────────
    for angle in ['pitch', 'roll', 'yaw']:
        col = df[angle]
        f[f'{angle}_mean']  = col.mean()
        f[f'{angle}_std']   = col.std()
        f[f'{angle}_range'] = col.max() - col.min()

    # ── Frequenzbereich (Kaufrequenz) ────────
    dt = df['seconds_elapsed'].diff().median()
    fs = 1.0 / dt if dt > 0 else 50.0

    signal = df['magnitude'].values
    freqs, psd = welch(signal, fs=fs, nperseg=min(256, len(signal)))

    # Kaufrequenzbereich: 0.5 - 4 Hz
    chew_mask = (freqs >= 0.5) & (freqs <= 4.0)
    if chew_mask.any():
        f['dominant_chew_freq'] = freqs[chew_mask][np.argmax(psd[chew_mask])]
        f['chew_band_power']    = psd[chew_mask].sum()
    else:
        f['dominant_chew_freq'] = 0
        f['chew_band_power']    = 0

    f['total_power']  = psd.sum()
    f['rhythmicity']  = f['chew_band_power'] / (f['total_power'] + 1e-9)

    return f


# ─────────────────────────────────────────
# 3. BATCH FUNKTION
# ─────────────────────────────────────────
import os

def build_chewing_matrix(data_dir):
    """
    Erwartet Ordnerstruktur:
    data/
    ├── apfel/
    │   ├── apfel_01.csv
    │   └── ...
    ├── banane/
    └── chips/
    """
    rows = []
    for label in os.listdir(data_dir):
        label_dir = os.path.join(data_dir, label)
        if not os.path.isdir(label_dir):
            continue
        for file in os.listdir(label_dir):
            if not file.endswith(".csv"):
                continue
            filepath = os.path.join(label_dir, file)
            try:
                df = load_session(filepath)
                session = file.replace(".csv", "")
                feat = extract_features(df, session, label)
                rows.append(feat)
                print(f"  ✓ {label}/{file}")
            except Exception as e:
                print(f"  ✗ Fehler: {label}/{file}: {e}")

    return pd.DataFrame(rows)


# ─────────────────────────────────────────
# 4. TEST MIT STILLE-AUFNAHME
# ─────────────────────────────────────────
print("="*55)
print("TEST mit Headphone.csv (stilles Sitzen)")
print("="*55)

df_test = load_session(f"{PFAD}/Headphone.csv")
print(f"Samples: {len(df_test)}, Dauer: {df_test['seconds_elapsed'].max():.1f}s")
print(f"Sampling Rate: ~{1/df_test['seconds_elapsed'].diff().median():.0f} Hz")

feat = extract_features(df_test, "headphone_still", "still")
print("\nExtrahierte Features:")
for k, v in feat.items():
    if k not in ['session', 'label']:
        print(f"  {k:30s}: {v:.5f}")


# ─────────────────────────────────────────
# 5. VISUALISIERUNG
# ─────────────────────────────────────────
fig = plt.figure(figsize=(14, 10))
fig.suptitle("Sensor Logger AirPods – Stilles Sitzen", fontsize=13, fontweight='bold')
gs = gridspec.GridSpec(3, 2, figure=fig, hspace=0.45, wspace=0.3)

plots = [
    ("Lineare Beschleunigung X", 'lin_x',        'royalblue'),
    ("Lineare Beschleunigung Y", 'lin_y',        'darkorange'),
    ("Lineare Beschleunigung Z", 'lin_z',        'green'),
    ("Bewegungs-Magnitude",      'magnitude',    'purple'),
    ("Pitch",                    'pitch',        'teal'),
    ("Yaw",                      'yaw',          'magenta'),
]

for i, (title, col, color) in enumerate(plots):
    row, c = divmod(i, 2)
    ax = fig.add_subplot(gs[row, c])
    ax.plot(df_test['seconds_elapsed'], df_test[col], color=color, linewidth=0.6)
    ax.set_title(title, fontsize=10, fontweight='bold')
    ax.set_xlabel("Zeit (s)", fontsize=8)
    ax.grid(True, alpha=0.3)

plt.savefig(f"{PFAD}/sensor_logger_test.png", dpi=150, bbox_inches='tight')
print(f"\nPlot gespeichert: sensor_logger_test.png")
print("\nNächster Schritt: Apfel-Aufnahme machen und vergleichen!")
