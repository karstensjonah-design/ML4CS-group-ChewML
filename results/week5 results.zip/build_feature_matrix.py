import pandas as pd
import numpy as np
import os

# ─────────────────────────────────────────
# PFAD - nur hier anpassen!
# ─────────────────────────────────────────
PFAD = "C:/Users/karst/OneDrive/Desktop/program"


# ─────────────────────────────────────────
# FEATURE EXTRACTION (eine CSV → ein Vektor)
# ─────────────────────────────────────────
def extract_features(df, session_name):
    f = {'session': session_name}

    # Vorverarbeitung
    for axis in ['x', 'y', 'z']:
        df[f'lin_{axis}'] = df[f'Acceleration_{axis}'] - df[f'Gravity_{axis}']
    df['magnitude'] = np.sqrt(df['lin_x']**2 + df['lin_y']**2 + df['lin_z']**2)

    # Lineare Beschleunigung
    for axis in ['x', 'y', 'z']:
        col = df[f'lin_{axis}']
        f[f'lin_{axis}_mean'] = col.mean()
        f[f'lin_{axis}_std']  = col.std()
        f[f'lin_{axis}_max']  = col.abs().max()

    # Magnitude
    f['magnitude_mean'] = df['magnitude'].mean()
    f['magnitude_std']  = df['magnitude'].std()
    f['magnitude_max']  = df['magnitude'].max()

    # Bewegungsereignisse
    f['movement_events'] = (df['magnitude'] > df['magnitude'].quantile(0.75)).sum()
    f['stillness_ratio'] = (df['magnitude'] < 0.02).mean()

    # Gyroscope
    for axis in ['x', 'y', 'z']:
        col = df[f'Rotation_{axis}']
        f[f'rot_{axis}_mean'] = col.mean()
        f[f'rot_{axis}_std']  = col.std()
        f[f'rot_{axis}_max']  = col.abs().max()

    # Euler-Winkel
    for angle in ['pitch', 'roll', 'yaw']:
        col = df[angle]
        f[f'{angle}_mean']  = col.mean()
        f[f'{angle}_std']   = col.std()
        f[f'{angle}_range'] = col.max() - col.min()

    return f


# ─────────────────────────────────────────
# BATCH FUNKTION (ganzer Ordner → Matrix)
# ─────────────────────────────────────────
def build_feature_matrix(data_dir):
    """
    Liest alle CSVs in einem Ordner ein und gibt
    eine Feature-Matrix zurück (eine Zeile pro Session).
    """
    rows = []
    csv_files = [f for f in os.listdir(data_dir) if f.endswith(".csv")]

    if len(csv_files) == 0:
        print("Keine CSV-Dateien gefunden!")
        return None

    for file in csv_files:
        filepath = os.path.join(data_dir, file)
        try:
            df = pd.read_csv(filepath, skipinitialspace=True)
            session_name = file.replace(".csv", "")
            feat = extract_features(df, session_name)
            rows.append(feat)
            print(f"  ✓ {file} verarbeitet")
        except Exception as e:
            print(f"  ✗ Fehler bei {file}: {e}")

    matrix = pd.DataFrame(rows).set_index('session')
    return matrix


# ─────────────────────────────────────────
# TEST MIT T-1 UND T-2
# ─────────────────────────────────────────
print("="*55)
print("Baue Feature-Matrix aus allen CSVs im Ordner...")
print("="*55)

matrix = build_feature_matrix(PFAD)

print(f"\n→ Matrix Shape: {matrix.shape[0]} Sessions × {matrix.shape[1]} Features")
print("\nErste Zeilen:")
print(matrix.to_string())

# Als CSV speichern – später Grundlage für ML
output_path = f"{PFAD}/feature_matrix.csv"
matrix.to_csv(output_path)
print(f"\n✓ Feature-Matrix gespeichert: feature_matrix.csv")
print("  → Diese Datei ist später der direkte Input für das ML-Modell!")
